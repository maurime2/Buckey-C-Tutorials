package employeeinterfacedemo;

public class EmployeeInterfaceDemo {

    public static void main(String[] args) {
        HourlyEmployee employee = new HourlyEmployee("Bill", 18.75f, 38);
        
        System.out.println( "Bill has been paid? " + employee.hasBeenPaid());
        employee.setBeenPaid(true);
        System.out.println( "Bill has been paid? " + employee.hasBeenPaid());
        System.out.println( "Payment amount of " + employee.getPaymentAmount() );
    }    
}
