package employeeinterfacedemo;

abstract public class Employee implements Payable {
    private String name;
    private boolean beenPaid = false;
    
    public Employee(String personName)
    {
        this.name=personName;
    }
    
    public String getName()
    {
        return this.name;
    }
    
    public boolean getBeenPaid()
    {
        return beenPaid;
    }
    
    public void setBeenPaid(boolean paid)
    {
        this.beenPaid=paid;
    }
}
