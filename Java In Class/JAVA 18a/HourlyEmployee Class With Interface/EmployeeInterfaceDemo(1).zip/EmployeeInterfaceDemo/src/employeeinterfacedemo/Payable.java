package employeeinterfacedemo;

public interface Payable { 
    boolean hasBeenPaid();
    double getPaymentAmount();
}
