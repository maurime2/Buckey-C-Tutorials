package discussion_110515;

public class Discussion_110515 {

    public static void main(String[] args) {
        Date a = new Date();
        Date b = new Date(a);
        
        System.out.println("object a: "+a.toString());
        System.out.println("object b: "+b.toString());
        
        b.setYear(2016);
        System.out.println("object b (year should be 2016): "+b.toString());
                
        try {
            Date d = new Date(2,29,2001);
        }
        catch(Exception e)
        {
            System.out.println("Error occurred: "+e.getMessage());
        }
        
        
        // Employee employee1 = new Employee("John", "Jones", d);
        // System.out.println(employee1.toString());
                   
        Employee employee2 = new Employee("Sam", "Smith", new Date(12,26,2013));
        System.out.println(employee2.toString());
        
        employee2.getHireDate().setMonth(2);
        //employee2.getHireDate().setYear(2000);
        employee2.getHireDate().setDay(29);        
        employee2.getHireDate().setYear(2000);
        System.out.println(employee2.toString());
    }
    
}
