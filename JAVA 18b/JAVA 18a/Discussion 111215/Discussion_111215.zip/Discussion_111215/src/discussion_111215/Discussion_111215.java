package discussion_111215;

public class Discussion_111215 {

    public static void main(String[] args) {
        Employee employee1 = new Employee("Bill", "Jones", new Date(1,1,2015));
        System.out.println(employee1.toString());
    }
    
}
